# Aarogyam
Aarogyam is an app that aims to reduce the hassle of medical papers and create a digital common medical database for all citizens of the country
